package com.sachin.gradebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradebookServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
